﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memory
{
    public class TruthTable
    {
        public Boolean A { get; set; }

        public Boolean X { get; set; }

        public Boolean D { get; set; }

        public Boolean R { get; set; }
    }
}
