﻿namespace sr
{
    internal class Close
    {
    }
}