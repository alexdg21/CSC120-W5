﻿using System;
namespace W5
{
    public class LogicGates
    {
        public bool InputA { get; set; }

        public bool InputB { get; set; }

        public bool Result { get; set; }

        public bool AndGate()
        {
            return InputA && InputB;
        }
        public bool OrGates()
        {
            return InputA || InputB;
        }
    }
}
